#ifndef PARSE_DATA
#define PARSE_DATA
#include "expscan.h"
typedef struct parse_data {
    perplex_t scanner;
} parse_data_t;
#endif
