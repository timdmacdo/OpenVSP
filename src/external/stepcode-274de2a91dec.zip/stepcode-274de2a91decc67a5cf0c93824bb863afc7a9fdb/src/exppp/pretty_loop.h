#ifndef PRETTY_LOOP_H
#define PRETTY_LOOP_H

#include <express/stmt.h>

void LOOPout( struct Loop_ *loop, int level );

#endif /* PRETTY_LOOP_H */
