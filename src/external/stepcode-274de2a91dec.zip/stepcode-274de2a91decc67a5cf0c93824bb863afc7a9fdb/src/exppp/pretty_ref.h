#ifndef PRETTY_REF_H
#define PRETTY_REF_H

#include <express/dict.h>
#include <express/linklist.h>

void REFout( Dictionary refdict, Linked_List reflist, char * type, int level );

#endif /* PRETTY_REF_H */
